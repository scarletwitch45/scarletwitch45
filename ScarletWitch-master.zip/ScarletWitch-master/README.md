
<div align="center">
  <img border-radius: 15px src="https://avatars.githubusercontent.com/u/83164448?v=4" width="200" height="200"/>
  <p align="center">
<a href="#"><img title="Scarlet Witch" src="https://img.shields.io/badge/ScarletWitchgreen?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
  <p align="center">
<a href="https://github.com/scarletwitch45"><img title="Author" src="https://img.shields.io/badge/Author-scarletwitch/ScarletWitch?color=blue&style=for-the-badge&logo=whatsapp"></a>
</p>
</div>
<p align="center">
Project created by <a href="https://github.com/scarletwitch45">Scarlet-Witch</a> to make it public
    <br>
       | © |
        Reserved |
    <br> 
</p>

----

  <p align="center">
  <a href="httsp://github.com/scarletwitch45/ScarletWitch">
    
<a href="https://github.com/scarletwitch45/followers"><img title="Followers" src="https://img.shields.io/github/followers/farhan-dqz?color=blue&style=flat-square"></a>
<a href="https://github.com/scarletwitch45/ScarletWitch/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/farhan-dqz/JulieMwol?color=blue&style=flat-square"></a>
<a href="https://github.com/scarletwitch45/ScarletWitch/network/members"><img title="Forks" src="https://img.shields.io/github/forks/scarletwitch45/ScarletWitch?color=blue&style=flat-square"></a>
<a href="https://github.com/scarletwitch45/ ScarletWitch/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/scarletwitch45/ScarletWitch?label=Watchers&color=blue&style=flat-square"></a>
</p>

## 📢 Guide
Click WA logo to Join Support Group 👇
    <br>
<br>
  [![join](https://github.com/Alien-alfa/PublicBot/blob/main/wlogo.svg.png)](https://chat.whatsapp.com/DGgx65N01mzAtilitItA0a)
  <div align="center">
       
  [![Readme Card](https://github-readme-stats.vercel.app/api/pin/?username=scarletwitch45&repo=PublicBot&theme=nightowl)](https://github.com/scarletwitch45/Scarlet-Witch.git)
  </div>
    
## Setup
<div align="center">

  ### Simple Method
  
[![Run on Repl.it](https://repl.it/badge/github/quiec/whatsAlfa)](https://replit.com/@phaticusthiccy/WhatsAsena-QR)

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/farhan-dqz/JulieMwol)
     </div>
<br>
<br >
If Repl.it not working Try Termux for Qr scanning.Just Copy the Link Below in Termux
```
bash <(curl -L https://t.ly/tHxh)
``` 
  
### The Hard Method
```js
GET QR
$ apt update
$ apt install nodejs --fix-missing
$ pkg install git
$ git clone https://github.com/scarletwitch45/ScarletWitch
$ cd ScarletWitch
$ chmod +x *
$ npm install @adiwajshing/baileys
$ npm install chalk
$ node qr.js
```
      
```js
SETUP
$ git clone https://github.com/scarletwitch45/ScarletWitch
$ cd ScarletWitch
$ chmod +x *
$ npm i
$ node qr.js
   // scan the qr using whatsapp web on your phone
$ node bot.js
```


### ⚠️ Warning! 
```
Due to Userbot; Your WhatsApp account may be banned.
This is an open source project, you are responsible for everything you do. 
Absolutely, Asena executives do not accept responsibility.
By establishing the Asena, you are deemed to have accepted these responsibilities.
```

## Developers
  <div align="center">
    
  [![Scarlet-Witch](https://github.com/scarletwitch45.png?size=100)](https://github.com/scarletwitch45)|  [![TOXIC4L!3N](https://github.com/Alien-alfa.png?size=100)](https://github.com/AI-VIKI) | [![afnanplk](https://github.com/afnanplk.png?size=100)](https://github.com/afnanplk) 
----|----|----
[scarletwitch45](https://github.com/scarletwitch45)  | [TOXIC4L!3N](https://github.com/AI-VIKI) | [afnanplk](https://github.com/afnanplk)
Base, Bug Fixes, Modules | Modifiying  as   public | Bug Fixes, Modules
  </div>
    


## License
This project is protected by `GNU General Public Licence v3.0` license.

### Disclaimer
`WhatsApp` name, its variations and the logo are registered trademarks of Facebook. We have nothing to do with the registered trademark
